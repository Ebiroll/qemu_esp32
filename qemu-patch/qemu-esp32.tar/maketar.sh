tar cvf qemu-esp32.tar hw/xtensa/esp32.c hw/xtensa/MemoryMapped.* target/xtensa/core-esp32* maketar.sh
