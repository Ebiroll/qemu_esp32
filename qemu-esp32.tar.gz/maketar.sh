tar cvf qemu-esp32.tar hw/xtensa/esp32.c target-xtensa/core-esp32* maketar.sh
